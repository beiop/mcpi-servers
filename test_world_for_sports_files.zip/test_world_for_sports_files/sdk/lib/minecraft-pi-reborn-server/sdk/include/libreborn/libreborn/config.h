#pragma once

#define MCPI_SERVER_MODE
#define MCPI_HEADLESS_MODE
#define MCPI_IS_APPIMAGE_BUILD
#define MCPI_USE_PREBUILT_ARMHF_TOOLCHAIN
/* #undef MCPI_USE_GLES1_COMPATIBILITY_LAYER */
#define MCPI_APP_BASE_TITLE "Minecraft: Pi Edition: Reborn"
#define MCPI_APP_TITLE "Minecraft: Pi Edition: Reborn (Server)"
#define MCPI_APP_ID "com.thebrokenrail.MCPIRebornServer"
#define MCPI_VERSION "2.5.4"
#define MCPI_VARIANT_NAME "minecraft-pi-reborn-server"
#define MCPI_SDK_DIR "lib/minecraft-pi-reborn-server/sdk"
#define MCPI_SKIN_SERVER "https://raw.githubusercontent.com/MCPI-Revival/Skins/data"
