#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "reborn-util" for configuration "Release"
set_property(TARGET reborn-util APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(reborn-util PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libreborn-util.so"
  IMPORTED_SONAME_RELEASE "libreborn-util.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS reborn-util )
list(APPEND _IMPORT_CHECK_FILES_FOR_reborn-util "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libreborn-util.so" )

# Import target "reborn-patch" for configuration "Release"
set_property(TARGET reborn-patch APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(reborn-patch PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libreborn-patch.so"
  IMPORTED_SONAME_RELEASE "libreborn-patch.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS reborn-patch )
list(APPEND _IMPORT_CHECK_FILES_FOR_reborn-patch "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libreborn-patch.so" )

# Import target "media-layer-core" for configuration "Release"
set_property(TARGET media-layer-core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(media-layer-core PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libmedia-layer-core.so"
  IMPORTED_SONAME_RELEASE "libmedia-layer-core.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS media-layer-core )
list(APPEND _IMPORT_CHECK_FILES_FOR_media-layer-core "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libmedia-layer-core.so" )

# Import target "init" for configuration "Release"
set_property(TARGET init APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(init PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libinit.so"
  IMPORTED_SONAME_RELEASE "libinit.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS init )
list(APPEND _IMPORT_CHECK_FILES_FOR_init "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libinit.so" )

# Import target "compat" for configuration "Release"
set_property(TARGET compat APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(compat PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libcompat.so"
  IMPORTED_SONAME_RELEASE "libcompat.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS compat )
list(APPEND _IMPORT_CHECK_FILES_FOR_compat "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libcompat.so" )

# Import target "readdir" for configuration "Release"
set_property(TARGET readdir APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(readdir PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libreaddir.so"
  IMPORTED_SONAME_RELEASE "libreaddir.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS readdir )
list(APPEND _IMPORT_CHECK_FILES_FOR_readdir "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libreaddir.so" )

# Import target "feature" for configuration "Release"
set_property(TARGET feature APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(feature PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libfeature.so"
  IMPORTED_SONAME_RELEASE "libfeature.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS feature )
list(APPEND _IMPORT_CHECK_FILES_FOR_feature "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libfeature.so" )

# Import target "game-mode" for configuration "Release"
set_property(TARGET game-mode APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(game-mode PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libgame-mode.so"
  IMPORTED_SONAME_RELEASE "libgame-mode.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS game-mode )
list(APPEND _IMPORT_CHECK_FILES_FOR_game-mode "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libgame-mode.so" )

# Import target "misc" for configuration "Release"
set_property(TARGET misc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(misc PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libmisc.so"
  IMPORTED_SONAME_RELEASE "libmisc.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS misc )
list(APPEND _IMPORT_CHECK_FILES_FOR_misc "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libmisc.so" )

# Import target "override" for configuration "Release"
set_property(TARGET override APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(override PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/liboverride.so"
  IMPORTED_SONAME_RELEASE "liboverride.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS override )
list(APPEND _IMPORT_CHECK_FILES_FOR_override "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/liboverride.so" )

# Import target "death" for configuration "Release"
set_property(TARGET death APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(death PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libdeath.so"
  IMPORTED_SONAME_RELEASE "libdeath.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS death )
list(APPEND _IMPORT_CHECK_FILES_FOR_death "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libdeath.so" )

# Import target "options" for configuration "Release"
set_property(TARGET options APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(options PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/liboptions.so"
  IMPORTED_SONAME_RELEASE "liboptions.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS options )
list(APPEND _IMPORT_CHECK_FILES_FOR_options "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/liboptions.so" )

# Import target "chat" for configuration "Release"
set_property(TARGET chat APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(chat PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libchat.so"
  IMPORTED_SONAME_RELEASE "libchat.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS chat )
list(APPEND _IMPORT_CHECK_FILES_FOR_chat "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libchat.so" )

# Import target "creative" for configuration "Release"
set_property(TARGET creative APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(creative PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libcreative.so"
  IMPORTED_SONAME_RELEASE "libcreative.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS creative )
list(APPEND _IMPORT_CHECK_FILES_FOR_creative "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libcreative.so" )

# Import target "bucket" for configuration "Release"
set_property(TARGET bucket APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(bucket PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libbucket.so"
  IMPORTED_SONAME_RELEASE "libbucket.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS bucket )
list(APPEND _IMPORT_CHECK_FILES_FOR_bucket "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libbucket.so" )

# Import target "textures" for configuration "Release"
set_property(TARGET textures APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(textures PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libtextures.so"
  IMPORTED_SONAME_RELEASE "libtextures.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS textures )
list(APPEND _IMPORT_CHECK_FILES_FOR_textures "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libtextures.so" )

# Import target "home" for configuration "Release"
set_property(TARGET home APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(home PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libhome.so"
  IMPORTED_SONAME_RELEASE "libhome.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS home )
list(APPEND _IMPORT_CHECK_FILES_FOR_home "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libhome.so" )

# Import target "version" for configuration "Release"
set_property(TARGET version APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(version PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libversion.so"
  IMPORTED_SONAME_RELEASE "libversion.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS version )
list(APPEND _IMPORT_CHECK_FILES_FOR_version "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libversion.so" )

# Import target "test" for configuration "Release"
set_property(TARGET test APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(test PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libtest.so"
  IMPORTED_SONAME_RELEASE "libtest.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS test )
list(APPEND _IMPORT_CHECK_FILES_FOR_test "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libtest.so" )

# Import target "server" for configuration "Release"
set_property(TARGET server APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(server PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libserver.so"
  IMPORTED_SONAME_RELEASE "libserver.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS server )
list(APPEND _IMPORT_CHECK_FILES_FOR_server "${_IMPORT_PREFIX}/lib/minecraft-pi-reborn-server/sdk/lib/libserver.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
